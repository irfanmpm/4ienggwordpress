<?php

return array (
  0 => 
  array (
    'index' => 1001,
    'id' => 'about-images-right-section-mc',
    'elementId' => 'about-1',
    'type' => 'section-available',
    'name' => 'About',
    'content' => '<div data-label="About" data-id="about-images-right-section-mc" data-export-id="about-images-right-section-mc" data-category="about" class="about-images-right-section content-section content-section-spacing"><div class="gridContainer"> <div class="row middle-sm text-center"><div class="col-sm-5 content-left-sm" data-type="column"> <h5>LOREM IPSUM DOLOR</h5> <h2>Enjoy the best <br/> <span style="font-family:Playfair Display,sans-serif;font-weight:700;font-style:italic;" href="#">design and functions</span> combined together</h2> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p> <a class="button color1" href="#">GET STARTED NOW</a></div> <div class="col-sm-7 space-bottom-xs"><div class="image-group-side-3-img"> <img class="topimg shadow-large" src="[tag_child_theme_uri]/customizer/sections/images/emp-02.jpg"/> <img class="rightimg shadow-large" src="[tag_child_theme_uri]/customizer/sections/images/emp-04.jpg"/> <div class="leftimg"> <img class="shadow-large" src="[tag_child_theme_uri]/customizer/sections/images/emp-03.jpg"/></div> </div></div> </div></div> </div>',
    'thumb' => '[tag_child_theme_uri]/assets/customizer/previews/sections/about-images-right-section-mc.png',
    'preview' => '[tag_child_theme_uri]/assets/customizer/previews/sections/about-images-right-section-mc.png',
    'description' => 'About',
    'category' => 'about',
    'prepend' => false,
    'pro' => false,
    'export' => 'module.exports={contentAligns:[\'[data-type="column"]:not(.section-title-col)\'],canRevertColumnsOnMobile:true,flexAligns:[\'.image-group-side-3-img\']}',
    'replace' => false,
  ),
  1 => 
  array (
    'index' => 1002,
    'id' => 'overlappable-7-mc',
    'elementId' => 'overlappable-1',
    'type' => 'section-available',
    'name' => 'Overlappable',
    'content' => '<div data-label="Overlappable" data-id="overlappable-7-mc" data-export-id="overlappable-7-mc" data-category="overlappable" class="overlappable-7-mc content-section content-section-spacing" data-overlap="true"><div class="gridContainer"> <div data-type="row" class="row shadow"><div class="col-xs-12 col-sm-6 col-md-3 col-padding-small col-padding-small-xs bg-color-white"> <div class="text-center"><div class="col-xs-12 col-sm-fit space-bottom-small-xs"> <i class="fa fa-refresh icon color-black large"></i></div> <div data-type="column" class="col-xs-12 col-sm"><h4>Responsive design</h4> <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p></div> </div></div> <div class="col-xs-12 col-sm-6 col-md-3 col-padding-small col-padding-small-xs bg-color-white"><div class="text-center"> <div class="col-xs-12 col-sm-fit space-bottom-small-xs"><i class="fa fa-paper-plane icon color-black large"></i></div> <div data-type="column" class="col-xs-12 col-sm"><h4>Parallax effect</h4> <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p></div> </div></div> <div class="col-xs-12 col-sm-6 col-md-3 col-padding-small col-padding-small-xs bg-color-white"><div class="text-center"> <div class="col-xs-12 col-sm-fit space-bottom-small-xs"><i class="fa fa-shopping-cart icon color-black large"></i></div> <div data-type="column" class="col-xs-12 col-sm"><h4>Woocommerce</h4> <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p></div> </div></div> <div class="col-xs-12 col-sm-6 col-md-3 col-padding-small col-padding-small-xs bg-color-white"><div class="text-center"> <div class="col-xs-12 col-sm-fit space-bottom-small-xs"><i class="fa fa-heart-o icon color-black large"></i></div> <div data-type="column" class="col-xs-12 col-sm"><h4>Content sections</h4> <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p></div> </div></div> </div></div> </div>',
    'thumb' => '[tag_child_theme_uri]/assets/customizer/previews/sections/overlappable-7-mc.png',
    'preview' => '[tag_child_theme_uri]/assets/customizer/previews/sections/overlappable-7-mc.png',
    'description' => 'Overlappable',
    'category' => 'overlappable',
    'prepend' => true,
    'pro' => false,
    'export' => 'module.exports={allowSectionTitleOptions:false,customColorDefault:\'#FF9800\',customColor:[{colorClass:{selector:\'.col-padding-small[class*="bg-"]\',prefix:\'bg-\',suffix:\'\'}}]}',
    'replace' => false,
  ),
);
